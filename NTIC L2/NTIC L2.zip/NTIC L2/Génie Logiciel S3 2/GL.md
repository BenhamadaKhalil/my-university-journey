---
title: Génie Logiciel – Index Général
date: 2025-06-14
category: Génie Logiciel
tags: [uml, modelisation, dcl, dob, activite, logiciel, class-diagram, se]
difficulty: Intermediate
estimated_time: 5–8 weeks
---
# 📘 Génie Logiciel – Index Complet des Cours UML & Modélisation

Ce dossier regroupe toutes les ressources théoriques, pratiques et visuelles nécessaires à la maîtrise de la modélisation logicielle UML : diagrammes statiques, dynamiques et fonctionnels, diagrammes de cas d'utilisation, ainsi que les pratiques orientées objet.

---

## 📂 Table des Matières

| #  | Titre                                                            | Format     | Lien                                                   |
|----|------------------------------------------------------------------|------------|--------------------------------------------------------|
| 1  | Introduction à la modélisation UML                               | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/UML]]                                             |
| 2  | Diagramme de Cas d’Utilisation – Théorie                         | Markdown   | [[Use case diagram chapter 3]]                      |
| 3  | Chapitre 4 – DCL / DOB (Diagrammes de Classe et d’Objet)         | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/DCL-DOB Chapter 4]]                               |
| 4  | Chap 4 – DCL / DOB (support PDF)                                 | PDF        | [[UNIV/NTIC L2/Génie Logiciel S3 2/Chap 4 (DCL DOB).pdf]]                               |
| 5  | Chapitre 5 – Modélisation selon l’axe dynamique (Activité, État) | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/Chapitre 5 Modélisation selon l'axe dynamique]]   |
| 6  | UML Chapter 2 – Structure complète des diagrammes UML            | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/UML chapter 2]]                                   |
| 7  | Pratique UML – Chapitre 2 (DCL, associations, classes)           | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/Practice Chapiter 2]]                             |
| 8  | Pratique UML – Chapitre 3 (États, transitions, activités)        | Markdown   | [[UNIV/NTIC L2/Génie Logiciel S3 2/Practice Chapter 3]]                              |
| 9  | Canvas UML – Synthèse Obsidian                                   | Canvas     | [[GL.canvas]]                                          |

---

## 🖼️ Références Visuelles

| #  | Image                                                   | Description                                      |
|----|----------------------------------------------------------|--------------------------------------------------|
| A  | `IMG.png`                                               | Rappel sur les axes de modélisation UML         |
| B  | `UML Quick Reference Card.jpeg`                         | Cartes des diagrammes (classe, état, activité…) |
| C  | `UML Quick Reference Card2.jpeg`                        | Version annotée ou alternative                  |
| D  | `Understanding UML Diagrams II.jpeg`                    | Classification en Diagrammes Structurels / Comportementaux |

---

## 📊 Catégories UML

### 🟧 Diagrammes Structurels
- Class Diagram
- Object Diagram
- Component Diagram
- Deployment Diagram
- Package Diagram
- Composite Structure Diagram

### 🟩 Diagrammes Comportementaux
- Activity Diagram
- Use Case Diagram
- State Machine Diagram
- Sequence Diagram
- Communication Diagram
- Timing Diagram
- Interaction Overview Diagram

Réf. : [[UNIV/NTIC L2/Génie Logiciel S3 2/UML]], [[UNIV/NTIC L2/Génie Logiciel S3 2/UML chapter 2]], Image "Understanding UML Diagrams II.jpeg"

---

## ✅ Ce que vous apprendrez

- Représenter les classes, objets, et relations statiques
- Comprendre les transitions, actions, événements dynamiques
- Créer des diagrammes complets de cas d’utilisation avec include/extend
- Appliquer les pratiques UML dans des exercices orientés projet
- Utiliser des supports PDF et visuels pour la révision ou présentation

---

🎓 *Besoin d’un plan PDF, d’un quiz ou d’un challenge à présenter ? Demandez-le !*
```

---

Let me know if you’d like:

- 🧪 Auto-generated quizzes based on these chapters
    
- 📥 One-click ZIP export of the full folder (Markdown + diagrams)
    
- 💬 Markdown + Canvas merged into an Obsidian presentation
    

Ready for the next step when you are!